 export class ContactForm {

    constructor(
        private nombre:string,
        private apellido:string,
        private email:String,
        private telefono:string,
        private mensaje:String
    ){}
}