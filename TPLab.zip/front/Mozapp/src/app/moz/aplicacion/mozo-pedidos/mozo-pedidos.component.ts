import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mozo-pedidos',
  templateUrl: './mozo-pedidos.component.html',
  styleUrls: ['./mozo-pedidos.component.css']
})
export class MozoPedidosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
