import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cajero-carta',
  templateUrl: './cajero-carta.component.html',
  styleUrls: ['./cajero-carta.component.css']
})
export class CajeroCartaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
