import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cajero-home',
  templateUrl: './cajero-home.component.html',
  styleUrls: ['./cajero-home.component.css']
})
export class CajeroHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
