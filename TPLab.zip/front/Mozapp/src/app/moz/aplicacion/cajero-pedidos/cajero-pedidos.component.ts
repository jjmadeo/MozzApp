import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cajero-pedidos',
  templateUrl: './cajero-pedidos.component.html',
  styleUrls: ['./cajero-pedidos.component.css']
})
export class CajeroPedidosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
