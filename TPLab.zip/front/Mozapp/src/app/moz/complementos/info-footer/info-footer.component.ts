import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-footer',
  templateUrl: './info-footer.component.html',
  styleUrls: ['./info-footer.component.css']
})
export class InfoFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
